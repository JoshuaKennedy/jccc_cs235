#ifndef CIRCLE_H
#define CIRCLE_H
class Circle
{
public:

private:

};

#endif