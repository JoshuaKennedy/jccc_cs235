#ifndef RECTANGLE_H
#define RECTANGLE_H
class Rectangle
{
public:

private:

};

#endif